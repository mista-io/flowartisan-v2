from .type import PlayMobileType  # noqa
