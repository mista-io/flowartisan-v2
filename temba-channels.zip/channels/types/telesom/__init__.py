from .type import TelesomType  # noqa
