from .type import M3TechType  # noqa
