from .type import BurstSMSType  # noqa
