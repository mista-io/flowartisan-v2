from .type import AfricasTalkingType  # noqa
