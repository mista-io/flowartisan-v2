from .type import ClickSendType  # noqa
