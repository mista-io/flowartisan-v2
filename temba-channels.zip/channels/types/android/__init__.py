from .type import AndroidType  # noqa
