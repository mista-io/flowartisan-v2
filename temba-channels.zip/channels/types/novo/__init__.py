from .type import NovoType  # noqa
