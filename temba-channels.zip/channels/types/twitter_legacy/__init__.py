from .type import TwitterLegacyType  # noqa
