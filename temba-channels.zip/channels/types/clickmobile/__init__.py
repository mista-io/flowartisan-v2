from .type import ClickMobileType  # noqa
