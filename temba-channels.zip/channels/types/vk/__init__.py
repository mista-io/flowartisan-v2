from .type import VKType  # noqa
