from .type import FacebookType  # noqa
