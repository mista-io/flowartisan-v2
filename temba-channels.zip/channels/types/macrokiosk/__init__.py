from .type import MacrokioskType  # noqa
