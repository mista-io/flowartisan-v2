from .type import WeChatType  # noqa
