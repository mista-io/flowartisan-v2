from .type import ChikkaType  # noqa
