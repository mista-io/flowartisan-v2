from .type import ArabiaCellType  # noqa
