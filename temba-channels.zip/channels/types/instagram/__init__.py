from .type import InstagramType  # noqa
