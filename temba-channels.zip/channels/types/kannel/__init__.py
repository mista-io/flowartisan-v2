from .type import KannelType  # noqa
