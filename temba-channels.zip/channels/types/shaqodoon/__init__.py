from .type import ShaqodoonType  # noqa
