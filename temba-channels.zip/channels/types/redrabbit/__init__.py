from .type import RedRabbitType  # noqa
