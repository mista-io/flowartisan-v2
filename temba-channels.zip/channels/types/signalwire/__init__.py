from .type import SignalWireType  # noqa
