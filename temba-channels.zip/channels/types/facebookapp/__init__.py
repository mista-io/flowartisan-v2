from .type import FacebookAppType  # noqa
