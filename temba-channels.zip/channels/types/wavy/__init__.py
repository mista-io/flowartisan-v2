from .type import WavyType  # noqa
