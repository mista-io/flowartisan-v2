from .type import InfobipType  # noqa
