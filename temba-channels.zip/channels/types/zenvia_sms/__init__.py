from .type import ZenviaSMSType  # noqa
